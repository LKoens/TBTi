

d1=zeros(2,8);
d5=zeros(3,8);
d10=zeros(3,8);

error1=zeros(2,8);
error5=zeros(3,8);
error10=zeros(3,8);

rerror1=zeros(2,8);
rerror5=zeros(3,8);
rerror10=zeros(3,8);

d1(1,:)=2;
d1(2,:)=1.1;

d5(1,:)=2;
d5(2,:)=0.4;
d5(3,:)=0.22;

d10(1,:)=2;
d10(2,:)=0.2;
d10(3,:)=0.11;
%% Error aspect=1

error1(1,1)=errorA(1,1);
error1(1,2)=errorA(2,2);
error1(1,3)=errorA(3,3);
error1(1,4)=errorA(4,4);
error1(1,5)=errorA(5,5);
error1(1,6)=errorA(6,6);
error1(1,7)=errorA(1,5);
error1(1,8)=errorA(2,4);

error1(2,1)=errorF(1,1);
error1(2,2)=errorF(2,2);
error1(2,3)=errorF(3,3);
error1(2,4)=errorF(4,4);
error1(2,5)=errorF(5,5);
error1(2,6)=errorF(6,6);
error1(2,7)=errorF(1,5);
error1(2,8)=errorF(2,4);

rerror1(1,1)=rerrorA(1,1);
rerror1(1,2)=rerrorA(2,2);
rerror1(1,3)=rerrorA(3,3);
rerror1(1,4)=rerrorA(4,4);
rerror1(1,5)=rerrorA(5,5);
rerror1(1,6)=rerrorA(6,6);
rerror1(1,7)=rerrorA(1,5);
rerror1(1,8)=rerrorA(2,4);

rerror1(2,1)=rerrorF(1,1);
rerror1(2,2)=rerrorF(2,2);
rerror1(2,3)=rerrorF(3,3);
rerror1(2,4)=rerrorF(4,4);
rerror1(2,5)=rerrorF(5,5);
rerror1(2,6)=rerrorF(6,6);
rerror1(2,7)=rerrorF(1,5);
rerror1(2,8)=rerrorF(2,4);

%% aspect =5


error5(1,1)=errorB(1,1);
error5(1,2)=errorB(2,2);
error5(1,3)=errorB(3,3);
error5(1,4)=errorB(4,4);
error5(1,5)=errorB(5,5);
error5(1,6)=errorB(6,6);
error5(1,7)=errorB(1,5);
error5(1,8)=errorB(2,4);

error5(2,1)=errorD(1,1);
error5(2,2)=errorD(2,2);
error5(2,3)=errorD(3,3);
error5(2,4)=errorD(4,4);
error5(2,5)=errorD(5,5);
error5(2,6)=errorD(6,6);
error5(2,7)=errorD(1,5);
error5(2,8)=errorD(2,4);

error5(3,1)=errorG(1,1);
error5(3,2)=errorG(2,2);
error5(3,3)=errorG(3,3);
error5(3,4)=errorG(4,4);
error5(3,5)=errorG(5,5);
error5(3,6)=errorG(6,6);
error5(3,7)=errorG(1,5);
error5(3,8)=errorG(2,4);

rerror5(1,1)=rerrorB(1,1);
rerror5(1,2)=rerrorB(2,2);
rerror5(1,3)=rerrorB(3,3);
rerror5(1,4)=rerrorB(4,4);
rerror5(1,5)=rerrorB(5,5);
rerror5(1,6)=rerrorB(6,6);
rerror5(1,7)=rerrorB(1,5);
rerror5(1,8)=rerrorB(2,4);

rerror5(2,1)=rerrorD(1,1);
rerror5(2,2)=rerrorD(2,2);
rerror5(2,3)=rerrorD(3,3);
rerror5(2,4)=rerrorD(4,4);
rerror5(2,5)=rerrorD(5,5);
rerror5(2,6)=rerrorD(6,6);
rerror5(2,7)=rerrorD(1,5);
rerror5(2,8)=rerrorD(2,4);

rerror5(3,1)=rerrorG(1,1);
rerror5(3,2)=rerrorG(2,2);
rerror5(3,3)=rerrorG(3,3);
rerror5(3,4)=rerrorG(4,4);
rerror5(3,5)=rerrorG(5,5);
rerror5(3,6)=rerrorG(6,6);
rerror5(3,7)=rerrorG(1,5);
rerror5(3,8)=rerrorG(2,4);

%% aspect =10



error10(1,1)=errorC(1,1);
error10(1,2)=errorC(2,2);
error10(1,3)=errorC(3,3);
error10(1,4)=errorC(4,4);
error10(1,5)=errorC(5,5);
error10(1,6)=errorC(6,6);
error10(1,7)=errorC(1,5);
error10(1,8)=errorC(2,4);

error10(2,1)=errorE(1,1);
error10(2,2)=errorE(2,2);
error10(2,3)=errorE(3,3);
error10(2,4)=errorE(4,4);
error10(2,5)=errorE(5,5);
error10(2,6)=errorE(6,6);
error10(2,7)=errorE(1,5);
error10(2,8)=errorE(2,4);

error10(3,1)=errorH(1,1);
error10(3,2)=errorH(2,2);
error10(3,3)=errorH(3,3);
error10(3,4)=errorH(4,4);
error10(3,5)=errorH(5,5);
error10(3,6)=errorH(6,6);
error10(3,7)=errorH(1,5);
error10(3,8)=errorH(2,4);

rerror10(1,1)=rerrorC(1,1);
rerror10(1,2)=rerrorC(2,2);
rerror10(1,3)=rerrorC(3,3);
rerror10(1,4)=rerrorC(4,4);
rerror10(1,5)=rerrorC(5,5);
rerror10(1,6)=rerrorC(6,6);
rerror10(1,7)=rerrorC(1,5);
rerror10(1,8)=rerrorC(2,4);

rerror10(2,1)=rerrorE(1,1);
rerror10(2,2)=rerrorE(2,2);
rerror10(2,3)=rerrorE(3,3);
rerror10(2,4)=rerrorE(4,4);
rerror10(2,5)=rerrorE(5,5);
rerror10(2,6)=rerrorE(6,6);
rerror10(2,7)=rerrorE(1,5);
rerror10(2,8)=rerrorE(2,4);

rerror10(3,1)=rerrorH(1,1);
rerror10(3,2)=rerrorH(2,2);
rerror10(3,3)=rerrorH(3,3);
rerror10(3,4)=rerrorH(4,4);
rerror10(3,5)=rerrorH(5,5);
rerror10(3,6)=rerrorH(6,6);
rerror10(3,7)=rerrorH(1,5);
rerror10(3,8)=rerrorH(2,4);